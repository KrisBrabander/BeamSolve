import tkinter as tk
from tkinter import ttk
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class ModernBuigingsCalculator:
    def __init__(self, root):
        self.root = root
        root.title("Moderne Buigingsberekeningen")
        root.configure(bg='#1e1e1e')  # Donkere achtergrond
        
        # Modern thema
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configureer moderne stijlen
        style.configure('Modern.TFrame', background='#1e1e1e')
        style.configure('Modern.TLabel', 
                       background='#1e1e1e', 
                       foreground='#ffffff',
                       font=('Segoe UI', 10))
        style.configure('Modern.TButton',
                       background='#0078d4',
                       foreground='#ffffff',
                       padding=10,
                       font=('Segoe UI', 10))
        style.configure('Modern.TEntry',
                       fieldbackground='#2d2d2d',
                       foreground='#ffffff',
                       insertcolor='#ffffff',
                       font=('Segoe UI', 10))
        
        # Hoofdframe
        main_frame = ttk.Frame(root, style='Modern.TFrame')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Balk visualisatie
        self.canvas = tk.Canvas(main_frame, 
                              bg='#2d2d2d',
                              height=200,
                              highlightthickness=0)
        self.canvas.pack(fill=tk.X, padx=5, pady=5)
        self.canvas.bind('<Button-1>', self.on_canvas_click)
        
        # Input frames
        input_container = ttk.Frame(main_frame, style='Modern.TFrame')
        input_container.pack(fill=tk.X, pady=10)
        
        # Profielgegevens
        profile_frame = ttk.LabelFrame(input_container, 
                                     text="Profielgegevens",
                                     style='Modern.TFrame')
        profile_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        
        # Invoervelden
        self.inputs = {}
        fields = [
            ("Hoogte (mm)", "100"),
            ("Breedte (mm)", "50"),
            ("Wanddikte (mm)", "5"),
            ("Lengte (mm)", "1000")
        ]
        
        for label, default in fields:
            frame = ttk.Frame(profile_frame, style='Modern.TFrame')
            frame.pack(fill=tk.X, pady=2)
            
            ttk.Label(frame, 
                     text=label,
                     style='Modern.TLabel').pack(side=tk.LEFT)
            
            var = tk.StringVar(value=default)
            entry = ttk.Entry(frame,
                            textvariable=var,
                            style='Modern.TEntry',
                            width=15)
            entry.pack(side=tk.RIGHT)
            self.inputs[label] = var
        
        # Belastingen frame
        load_frame = ttk.LabelFrame(input_container,
                                  text="Belastingen",
                                  style='Modern.TFrame')
        load_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5)
        
        # Belastingen lijst
        self.load_list = tk.Listbox(load_frame,
                                  bg='#2d2d2d',
                                  fg='#ffffff',
                                  selectmode=tk.SINGLE,
                                  font=('Segoe UI', 10),
                                  height=6)
        self.load_list.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Knoppen
        btn_frame = ttk.Frame(load_frame, style='Modern.TFrame')
        btn_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(btn_frame,
                  text="Verwijder",
                  style='Modern.TButton',
                  command=self.remove_load).pack(side=tk.LEFT)
        
        ttk.Button(btn_frame,
                  text="Bereken",
                  style='Modern.TButton',
                  command=self.update_graphs).pack(side=tk.RIGHT)
        
        # Grafieken
        self.fig = Figure(figsize=(12, 4), facecolor='#1e1e1e')
        self.axes = []
        titles = ['Moment', 'Dwarskracht', 'Doorbuiging', 'Spanning']
        
        for i, title in enumerate(titles):
            ax = self.fig.add_subplot(141 + i)
            ax.set_facecolor('#2d2d2d')
            ax.set_title(title, color='white')
            ax.grid(True, color='#404040')
            ax.tick_params(colors='white')
            for spine in ax.spines.values():
                spine.set_color('#404040')
            self.axes.append(ax)
        
        self.canvas_plots = FigureCanvasTkAgg(self.fig, master=main_frame)
        self.canvas_plots.draw()
        self.canvas_plots.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Initialisatie
        self.loads = []
        self.draw_beam()
        self.update_graphs()
    
    def draw_beam(self):
        self.canvas.delete("all")
        width = self.canvas.winfo_width()
        height = self.canvas.winfo_height()
        margin = 50
        beam_height = 40
        y_mid = height // 2
        
        # Teken balk
        self.canvas.create_rectangle(
            margin, y_mid - beam_height//2,
            width - margin, y_mid + beam_height//2,
            fill='#0078d4', outline='#0078d4'
        )
        
        # Teken steunpunten
        for x in [margin, width - margin]:
            self.canvas.create_polygon(
                x - 15, y_mid + beam_height//2,
                x + 15, y_mid + beam_height//2,
                x, y_mid + beam_height//2 + 30,
                fill='#00b7c3'
            )
        
        # Teken belastingen
        for pos, force in self.loads:
            x = margin + (width - 2*margin) * pos/1000
            # Pijl
            self.canvas.create_line(
                x, y_mid - beam_height//2 - 50,
                x, y_mid - beam_height//2,
                fill='#e81123', width=2, arrow=tk.LAST
            )
            # Tekst
            self.canvas.create_text(
                x, y_mid - beam_height//2 - 60,
                text=f"{force}N",
                fill='white',
                font=('Segoe UI', 10)
            )
    
    def on_canvas_click(self, event):
        width = self.canvas.winfo_width()
        margin = 50
        x = event.x
        
        if margin <= x <= width - margin:
            pos = (x - margin) / (width - 2*margin) * 1000
            
            # Modern dialog voor krachtinvoer
            dialog = tk.Toplevel(self.root)
            dialog.title("Voer kracht in")
            dialog.geometry("300x150")
            dialog.configure(bg='#1e1e1e')
            dialog.transient(self.root)
            dialog.grab_set()
            
            ttk.Label(dialog,
                     text="Kracht (N):",
                     style='Modern.TLabel').pack(pady=10)
            
            force_var = tk.StringVar(value="1000")
            force_entry = ttk.Entry(dialog,
                                  textvariable=force_var,
                                  style='Modern.TEntry')
            force_entry.pack(pady=10)
            
            def add_force():
                try:
                    force = float(force_var.get())
                    self.loads.append((pos, force))
                    self.load_list.insert(tk.END, 
                                        f"Pos: {pos:.0f}mm, Kracht: {force}N")
                    self.draw_beam()
                    self.update_graphs()
                    dialog.destroy()
                except ValueError:
                    pass
            
            ttk.Button(dialog,
                      text="OK",
                      style='Modern.TButton',
                      command=add_force).pack(pady=10)
    
    def remove_load(self):
        selection = self.load_list.curselection()
        if selection:
            index = selection[0]
            del self.loads[index]
            self.load_list.delete(index)
            self.draw_beam()
            self.update_graphs()
    
    def update_graphs(self):
        try:
            L = float(self.inputs["Lengte (mm)"].get())
            x = np.linspace(0, L, 100)
            
            if self.loads:
                moment = np.zeros_like(x)
                shear = np.zeros_like(x)
                deflection = np.zeros_like(x)
                
                for pos, F in self.loads:
                    # Moment
                    moment += np.where(x <= pos,
                                     F * pos * x / L,
                                     F * (L - x) * (L - pos) / L)
                    
                    # Dwarskracht
                    shear += np.where(x < pos,
                                    F * (L - pos) / L,
                                    -F * pos / L)
                    
                    # Doorbuiging
                    E = 210000  # N/mm2
                    I = (float(self.inputs["Breedte (mm)"].get()) *
                         float(self.inputs["Hoogte (mm)"].get())**3) / 12
                    EI = E * I
                    deflection += F * x * (L - x) * (L + x - pos) / (6 * L * EI)
                
                # Spanning
                h = float(self.inputs["Hoogte (mm)"].get())
                stress = np.abs(moment) * (h/2) / I
                
                # Update plots
                for ax in self.axes:
                    ax.clear()
                    ax.grid(True, color='#404040')
                    ax.tick_params(colors='white')
                    for spine in ax.spines.values():
                        spine.set_color('#404040')
                
                self.axes[0].plot(x, moment, color='#0078d4')
                self.axes[0].set_title("Moment", color='white')
                
                self.axes[1].plot(x, shear, color='#00b7c3')
                self.axes[1].set_title("Dwarskracht", color='white')
                
                self.axes[2].plot(x, deflection, color='#e81123')
                self.axes[2].set_title("Doorbuiging", color='white')
                
                self.axes[3].plot(x, stress, color='#ffb900')
                self.axes[3].set_title("Spanning", color='white')
                
                self.fig.tight_layout()
                self.canvas_plots.draw()
        
        except ValueError:
            pass

if __name__ == '__main__':
    root = tk.Tk()
    root.geometry("1200x800")
    app = ModernBuigingsCalculator(root)
    root.mainloop()
