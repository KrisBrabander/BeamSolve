import sys
import numpy as np
import tkinter as tk
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from modern_style import apply_modern_style

class InteractieveBalk:
    def __init__(self, root):
        self.root = root
        root.title('Buigingsberekeningen')
        root.geometry('1200x800')
        
        # Pas moderne stijl toe
        self.colors = apply_modern_style()
        root.configure(bg=self.colors['bg_dark'])
        
        # Matplotlib stijl
        plt.style.use('dark_background')
        
        # Hoofdframe
        main_frame = ttk.Frame(root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Balk visualisatie frame
        self.balk_frame = ttk.LabelFrame(main_frame, text="Balk Visualisatie", padding="10")
        self.balk_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5, pady=5)
        
        # Canvas voor balk
        self.balk_canvas = tk.Canvas(self.balk_frame, width=800, height=200, 
                                   bg=self.colors['bg_light'],
                                   highlightthickness=0)
        self.balk_canvas.pack(fill=tk.BOTH, expand=True)
        self.balk_canvas.bind('<Button-1>', self.on_canvas_click)
        
        # Profielgegevens frame
        input_frame = ttk.LabelFrame(main_frame, text="Profielgegevens", padding="10")
        input_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N), padx=5, pady=5)
        
        # Invoervelden met moderne layout
        labels = [
            ('Hoogte (mm):', '100'),
            ('Breedte (mm):', '50'),
            ('Wanddikte (mm):', '5'),
            ('Lengte (mm):', '1000')
        ]
        self.inputs = {}
        for i, (label, default) in enumerate(labels):
            container = ttk.Frame(input_frame)
            container.grid(row=i, column=0, sticky=tk.W, pady=2)
            
            ttk.Label(container, text=label).pack(side=tk.LEFT, padx=(0, 10))
            var = tk.StringVar(value=default)
            entry = ttk.Entry(container, textvariable=var, width=10)
            entry.pack(side=tk.LEFT)
            self.inputs[label] = var
        
        # Belastingen frame
        self.belasting_frame = ttk.LabelFrame(main_frame, text="Belastingen", padding="10")
        self.belasting_frame.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N), padx=5, pady=5)
        
        # Lijst met belastingen
        self.belastingen = []
        self.belasting_listbox = tk.Listbox(self.belasting_frame, height=5,
                                          bg=self.colors['bg_light'],
                                          fg=self.colors['text'],
                                          selectmode=tk.SINGLE,
                                          highlightthickness=0,
                                          selectbackground=self.colors['accent'])
        self.belasting_listbox.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        # Knoppen voor belastingen
        btn_frame = ttk.Frame(self.belasting_frame)
        btn_frame.pack(fill=tk.X, pady=5)
        ttk.Button(btn_frame, text="Verwijder", command=self.verwijder_belasting).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Bereken", command=self.update_all).pack(side=tk.RIGHT, padx=5)
        
        # Grafieken frame
        plot_frame = ttk.Frame(main_frame)
        plot_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        
        # Matplotlib figuur voor grafieken
        self.fig = Figure(figsize=(12, 3), facecolor=self.colors['bg_dark'])
        self.axes = []
        for i in range(4):
            ax = self.fig.add_subplot(141 + i)
            ax.set_facecolor(self.colors['bg_light'])
            self.axes.append(ax)
        
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Grid configuratie
        root.grid_rowconfigure(0, weight=1)
        root.grid_columnconfigure(0, weight=1)
        main_frame.grid_rowconfigure(2, weight=1)
        main_frame.grid_columnconfigure(0, weight=1)
        main_frame.grid_columnconfigure(1, weight=1)
        
        # Initialisatie
        self.teken_balk()
        self.update_all()
    
    def teken_balk(self):
        self.balk_canvas.delete("all")
        
        # Canvas afmetingen
        canvas_width = self.balk_canvas.winfo_width()
        canvas_height = self.balk_canvas.winfo_height()
        
        # Balk parameters
        margin = 50
        balk_hoogte = 40
        try:
            L = float(self.inputs['Lengte (mm):'].get())
            schaal = (canvas_width - 2 * margin) / L
        except:
            L = 1000
            schaal = (canvas_width - 2 * margin) / L
        
        y_midden = canvas_height / 2
        
        # Teken hulplijnen voor klikken
        for x in range(margin, canvas_width - margin, 100):
            self.balk_canvas.create_line(
                x, y_midden - balk_hoogte,
                x, y_midden + balk_hoogte,
                fill=self.colors['text'],
                dash=(2, 2)
            )
            pos = (x - margin) / schaal
            self.balk_canvas.create_text(
                x, y_midden + balk_hoogte + 15,
                text=f"{pos:.0f}", font=('Arial', 8),
                fill=self.colors['text']
            )
        
        # Teken steunpunten (driehoeken)
        self.balk_canvas.create_polygon(
            margin - 15, y_midden + balk_hoogte/2,
            margin + 15, y_midden + balk_hoogte/2,
            margin, y_midden + balk_hoogte/2 + 30,
            fill=self.colors['accent']
        )
        self.balk_canvas.create_polygon(
            canvas_width - margin - 15, y_midden + balk_hoogte/2,
            canvas_width - margin + 15, y_midden + balk_hoogte/2,
            canvas_width - margin, y_midden + balk_hoogte/2 + 30,
            fill=self.colors['accent']
        )
        
        # Teken balk met schaduw effect
        self.balk_canvas.create_rectangle(
            margin + 2, y_midden - balk_hoogte/2 + 2,
            canvas_width - margin + 2, y_midden + balk_hoogte/2 + 2,
            fill=self.colors['bg_dark']
        )
        self.balk_canvas.create_rectangle(
            margin, y_midden - balk_hoogte/2,
            canvas_width - margin, y_midden + balk_hoogte/2,
            fill=self.colors['bg_light'],
            outline=self.colors['text']
        )
        
        # Teken belastingen met verbeterde visualisatie
        for pos, kracht in self.belastingen:
            x = margin + pos * schaal
            if kracht > 0:  # Pijl naar beneden
                # Pijlschacht
                self.balk_canvas.create_line(
                    x, y_midden - balk_hoogte/2 - 60,
                    x, y_midden - balk_hoogte/2,
                    width=2,
                    fill=self.colors['accent']
                )
                # Pijlpunt
                self.balk_canvas.create_polygon(
                    x - 8, y_midden - balk_hoogte/2 - 8,
                    x + 8, y_midden - balk_hoogte/2 - 8,
                    x, y_midden - balk_hoogte/2,
                    fill=self.colors['accent']
                )
                # Krachtwaarde
                self.balk_canvas.create_text(
                    x, y_midden - balk_hoogte/2 - 70,
                    text=f"{kracht:.0f} N",
                    font=('Arial', 10, 'bold'),
                    fill=self.colors['accent']
                )
                # Positie
                self.balk_canvas.create_text(
                    x, y_midden - balk_hoogte/2 - 85,
                    text=f"{pos:.0f} mm",
                    font=('Arial', 8),
                    fill=self.colors['text']
                )
        
        # Teken maatlijn onderaan
        y_maatlijn = y_midden + balk_hoogte/2 + 50
        self.balk_canvas.create_line(
            margin, y_maatlijn,
            canvas_width - margin, y_maatlijn,
            arrow=tk.BOTH,
            fill=self.colors['text']
        )
        self.balk_canvas.create_text(
            canvas_width/2, y_maatlijn + 20,
            text=f"{L:.0f} mm",
            font=('Arial', 10, 'bold'),
            fill=self.colors['text']
        )
        
        # Teken "Klik om kracht toe te voegen" tekst
        if not self.belastingen:
            self.balk_canvas.create_text(
                canvas_width/2, y_midden - balk_hoogte - 20,
                text="Klik op de balk om een kracht toe te voegen",
                font=('Arial', 10),
                fill=self.colors['text']
            )
    
    def on_canvas_click(self, event):
        # Canvas parameters
        margin = 50
        balk_hoogte = 40
        canvas_height = self.balk_canvas.winfo_height()
        y_midden = canvas_height / 2
        
        # Check of klik binnen balk gebied is
        if not (y_midden - balk_hoogte <= event.y <= y_midden + balk_hoogte):
            return
            
        try:
            L = float(self.inputs['Lengte (mm):'].get())
            schaal = (self.balk_canvas.winfo_width() - 2 * margin) / L
            pos = (event.x - margin) / schaal
            
            if 0 <= pos <= L:
                # Maak een klein dialoogvenster voor de krachtinvoer
                dialog = tk.Toplevel(self.root)
                dialog.title("Voer kracht in")
                dialog.geometry("250x150")
                dialog.transient(self.root)
                dialog.grab_set()  # Maak het modaal
                
                # Centreer het dialoogvenster
                dialog.geometry(f"+{self.root.winfo_x() + 200}+{self.root.winfo_y() + 200}")
                
                # Frame voor invoer
                frame = ttk.Frame(dialog, padding="10")
                frame.pack(fill=tk.BOTH, expand=True)
                
                ttk.Label(frame, text=f"Positie: {pos:.0f} mm").pack(pady=5)
                ttk.Label(frame, text="Kracht (N):").pack(pady=5)
                
                kracht_var = tk.StringVar(value="1000")
                entry = ttk.Entry(frame, textvariable=kracht_var, width=15)
                entry.pack(pady=5)
                entry.select_range(0, tk.END)
                entry.focus()
                
                def toevoegen():
                    try:
                        kracht = float(kracht_var.get())
                        self.belastingen.append((pos, kracht))
                        self.update_belastingen_lijst()
                        self.update_all()
                        dialog.destroy()
                    except ValueError:
                        pass
                
                def on_enter(event):
                    toevoegen()
                
                # Bind Enter toets
                entry.bind('<Return>', on_enter)
                
                btn_frame = ttk.Frame(frame)
                btn_frame.pack(fill=tk.X, pady=10)
                ttk.Button(btn_frame, text="Annuleren", command=dialog.destroy).pack(side=tk.LEFT, padx=5)
                ttk.Button(btn_frame, text="OK", command=toevoegen).pack(side=tk.RIGHT, padx=5)
                
        except ValueError:
            pass
    
    def update_belastingen_lijst(self):
        self.belasting_listbox.delete(0, tk.END)
        for pos, kracht in self.belastingen:
            self.belasting_listbox.insert(tk.END, f"Pos: {pos:.0f} mm, Kracht: {kracht:.0f} N")
    
    def verwijder_belasting(self):
        selection = self.belasting_listbox.curselection()
        if selection:
            index = selection[0]
            del self.belastingen[index]
            self.update_belastingen_lijst()
            self.update_all()
    
    def bereken_traagheidsmoment(self, h, b, t):
        h_binnen = h - 2 * t
        b_binnen = b - 2 * t
        return (b * h**3 - b_binnen * h_binnen**3) / 12
    
    def bereken_weerstandsmoment(self, I, h):
        return I / (h / 2)
    
    def bereken_moment(self, x, L):
        M = 0
        for pos, F in self.belastingen:
            if x <= pos:
                M += F * pos * x / L
            else:
                M += F * (L - x) * (L - pos) / L
        return M
    
    def bereken_dwarskracht(self, x, L):
        V = 0
        for pos, F in self.belastingen:
            if x < pos:
                V += F * (L - pos) / L
            else:
                V += -F * pos / L
        return V
    
    def bereken_doorbuiging(self, x, L, EI):
        y = 0
        for pos, F in self.belastingen:
            y += F * x * (L - x) * (L + x - pos) / (6 * L * EI)
        return y
    
    def update_all(self):
        self.teken_balk()
        
        try:
            # Lees profielgegevens
            h = float(self.inputs['Hoogte (mm):'].get())
            b = float(self.inputs['Breedte (mm):'].get())
            t = float(self.inputs['Wanddikte (mm):'].get())
            L = float(self.inputs['Lengte (mm):'].get())
            
            if not self.belastingen:
                return
                
            # Bereken eigenschappen
            I = self.bereken_traagheidsmoment(h, b, t)
            W = self.bereken_weerstandsmoment(I, h)
            E = 210000  # N/mm2
            EI = E * I
            
            # Bereken waarden
            x = np.linspace(0, L, 100)
            moment = [self.bereken_moment(xi, L) for xi in x]
            dwarskracht = [self.bereken_dwarskracht(xi, L) for xi in x]
            doorbuiging = [self.bereken_doorbuiging(xi, L, EI) for xi in x]
            spanning = [abs(M) / W for M in moment]
            
            # Update plots
            titles = ['Momentenlijn', 'Dwarskrachtenlijn', 'Doorbuiging', 'Spanningsverdeling']
            data = [moment, dwarskracht, doorbuiging, spanning]
            ylabels = ['Moment (Nmm)', 'Dwarskracht (N)', 'Doorbuiging (mm)', 'Spanning (N/mm²)']
            
            for ax, title, d, ylabel in zip(self.axes, titles, data, ylabels):
                ax.clear()
                ax.plot(x, d)
                ax.set_title(title, fontsize=8)
                ax.set_xlabel('Positie (mm)', fontsize=8)
                ax.set_ylabel(ylabel, fontsize=8)
                ax.tick_params(labelsize=8)
                ax.grid(True)
            
            self.fig.tight_layout()
            self.canvas.draw()
            
        except ValueError:
            pass

if __name__ == '__main__':
    root = tk.Tk()
    app = InteractieveBalk(root)
    root.mainloop()
