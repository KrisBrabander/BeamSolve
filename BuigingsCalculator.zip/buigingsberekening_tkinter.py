import tkinter as tk
from tkinter import ttk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class BuigingsCalculator:
    def __init__(self, root):
        self.root = root
        root.title('Buigingsberekeningen')
        
        # Hoofdframe
        main_frame = ttk.Frame(root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Invoerpaneel
        input_frame = ttk.LabelFrame(main_frame, text="Invoergegevens", padding="10")
        input_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5)
        
        # Profielgegevens
        ttk.Label(input_frame, text="1. Profielgegevens").grid(row=0, column=0, columnspan=2, sticky=tk.W)
        
        # Labels en invoervelden
        labels = ['Hoogte (mm):', 'Breedte (mm):', 'Wanddikte (mm):']
        self.inputs = {}
        
        for i, label in enumerate(labels, start=1):
            ttk.Label(input_frame, text=label).grid(row=i, column=0, sticky=tk.W)
            var = tk.StringVar(value="100" if i == 1 else "50" if i == 2 else "5")
            entry = ttk.Entry(input_frame, textvariable=var, width=10)
            entry.grid(row=i, column=1, padx=5)
            self.inputs[label] = var
        
        # Overspanning
        ttk.Label(input_frame, text="\n2. Overspanning").grid(row=4, column=0, columnspan=2, sticky=tk.W)
        ttk.Label(input_frame, text="Lengte (mm):").grid(row=5, column=0, sticky=tk.W)
        self.lengte_var = tk.StringVar(value="1000")
        ttk.Entry(input_frame, textvariable=self.lengte_var, width=10).grid(row=5, column=1, padx=5)
        
        # Belasting
        ttk.Label(input_frame, text="\n3. Belasting").grid(row=6, column=0, columnspan=2, sticky=tk.W)
        ttk.Label(input_frame, text="Kracht (N):").grid(row=7, column=0, sticky=tk.W)
        self.kracht_var = tk.StringVar(value="1000")
        ttk.Entry(input_frame, textvariable=self.kracht_var, width=10).grid(row=7, column=1, padx=5)
        
        ttk.Label(input_frame, text="Positie (mm):").grid(row=8, column=0, sticky=tk.W)
        self.positie_var = tk.StringVar(value="500")
        ttk.Entry(input_frame, textvariable=self.positie_var, width=10).grid(row=8, column=1, padx=5)
        
        # Bereken knop
        ttk.Button(input_frame, text="Bereken", command=self.update_plots).grid(row=9, column=0, columnspan=2, pady=10)
        
        # Grafieken frame
        plot_frame = ttk.Frame(main_frame)
        plot_frame.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5)
        
        # Matplotlib figuur
        self.fig, self.axes = plt.subplots(2, 2, figsize=(10, 8))
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Initiële plot
        self.update_plots()
        
    def bereken_traagheidsmoment(self, h, b, t):
        h_binnen = h - 2 * t
        b_binnen = b - 2 * t
        return (b * h**3 - b_binnen * h_binnen**3) / 12
    
    def bereken_weerstandsmoment(self, I, h):
        return I / (h / 2)
    
    def bereken_moment(self, F, a, L, x):
        if x <= a:
            return F * a * x / L
        else:
            return F * (L - x) * (L - a) / L
    
    def bereken_dwarskracht(self, F, a, L, x):
        if x < a:
            return F * (L - a) / L
        else:
            return -F * a / L
    
    def bereken_doorbuiging(self, F, a, L, x, EI):
        return F * x * (L - x) * (L + x - a) / (6 * L * EI)
    
    def update_plots(self):
        try:
            # Lees invoerwaarden
            h = float(self.inputs['Hoogte (mm):'].get())
            b = float(self.inputs['Breedte (mm):'].get())
            t = float(self.inputs['Wanddikte (mm):'].get())
            L = float(self.lengte_var.get())
            F = float(self.kracht_var.get())
            a = float(self.positie_var.get())
            
            # Bereken eigenschappen
            I = self.bereken_traagheidsmoment(h, b, t)
            W = self.bereken_weerstandsmoment(I, h)
            E = 210000  # N/mm2
            EI = E * I
            
            # Bereken waarden
            x = np.linspace(0, L, 100)
            moment = [self.bereken_moment(F, a, L, xi) for xi in x]
            dwarskracht = [self.bereken_dwarskracht(F, a, L, xi) for xi in x]
            doorbuiging = [self.bereken_doorbuiging(F, a, L, xi, EI) for xi in x]
            spanning = [abs(M) / W for M in moment]
            
            # Update plots
            self.fig.clear()
            self.axes = self.fig.subplots(2, 2)
            
            titles = ['Momentenlijn', 'Dwarskrachtenlijn', 'Doorbuiging', 'Spanningsverdeling']
            data = [moment, dwarskracht, doorbuiging, spanning]
            ylabels = ['Moment (Nmm)', 'Dwarskracht (N)', 'Doorbuiging (mm)', 'Spanning (N/mm²)']
            
            for ax, title, d, ylabel in zip(self.axes.flat, titles, data, ylabels):
                ax.plot(x, d)
                ax.set_title(title)
                ax.set_xlabel('Positie (mm)')
                ax.set_ylabel(ylabel)
                ax.grid(True)
            
            self.fig.tight_layout()
            self.canvas.draw()
            
        except ValueError:
            print("Voer geldige numerieke waarden in")

if __name__ == '__main__':
    root = tk.Tk()
    app = BuigingsCalculator(root)
    root.mainloop()
