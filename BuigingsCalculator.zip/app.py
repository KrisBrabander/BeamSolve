from flask import Flask, render_template, request, jsonify
import numpy as np
import matplotlib.pyplot as plt
import io
import base64
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

app = Flask(__name__)

class BuigingsCalculator:
    def __init__(self):
        # Materiaal eigenschappen volgens EN 1993-1-1 (Eurocode 3)
        self.materials = {
            "S235": {
                "E": 210000,
                "sigma_y": 235,  # Vloeigrens [N/mm²]
                "gamma_M0": 1.0,  # Materiaalfactor volgens EC3
                "description": "Constructiestaal S235 (EN 10025-2)",
                "density": 7850  # kg/m³
            },
            "S275": {
                "E": 210000,
                "sigma_y": 275,
                "gamma_M0": 1.0,
                "description": "Constructiestaal S275 (EN 10025-2)",
                "density": 7850
            },
            "S355": {
                "E": 210000,
                "sigma_y": 355,
                "gamma_M0": 1.0,
                "description": "Constructiestaal S355 (EN 10025-2)",
                "density": 7850
            },
            "EN-AW 6061-T6": {
                "E": 70000,
                "sigma_y": 240,
                "gamma_M0": 1.1,
                "description": "Aluminium 6061-T6 (EN 755-2)",
                "density": 2700
            }
        }
        
        # Standaard profielen volgens EN 10025
        self.standard_profiles = {
            "I-profiel": {
                "HEA 100": {"h": 96, "b": 100, "t": 5, "tf": 8, "r": 12},
                "HEA 200": {"h": 190, "b": 200, "t": 6.5, "tf": 10, "r": 18},
                "HEA 300": {"h": 290, "b": 300, "t": 8.5, "tf": 14, "r": 27},
                "IPE 100": {"h": 100, "b": 55, "t": 4.1, "tf": 5.7, "r": 7},
                "IPE 200": {"h": 200, "b": 100, "t": 5.6, "tf": 8.5, "r": 12},
                "IPE 300": {"h": 300, "b": 150, "t": 7.1, "tf": 10.7, "r": 15}
            },
            "U-profiel": {
                "UNP 100": {"h": 100, "b": 50, "t": 6, "tf": 8.5, "r": 8},
                "UNP 200": {"h": 200, "b": 75, "t": 8.5, "tf": 11.5, "r": 11.5},
                "UNP 300": {"h": 300, "b": 100, "t": 10, "tf": 16, "r": 16}
            },
            "Koker": {
                "100x50x5": {"h": 100, "b": 50, "t": 5, "r": 5},
                "200x100x8": {"h": 200, "b": 100, "t": 8, "r": 8},
                "300x150x10": {"h": 300, "b": 150, "t": 10, "r": 10}
            }
        }

    def calculate_I(self, h, b, t, tf=None, r=None, profile_type="Koker"):
        """Bereken traagheidsmoment volgens EN 1993-1-1"""
        if profile_type == "Koker":
            # Inclusief afrondingsstraal voor nauwkeurigere berekening
            r = r or t
            A_hoeken = (4 * np.pi * r**2) / 4  # Oppervlakte van de 4 hoeken
            I_hoeken = (4 * np.pi * r**4) / 64 + A_hoeken * ((h-2*r)/2)**2
            I_flenzen = 2 * (b * t * ((h-2*t)/2)**2)
            I_lijven = 2 * (t * (h-2*t)**3) / 12
            return I_hoeken + I_flenzen + I_lijven
        else:
            # I- of U-profiel met flens-lijf overgang radius
            r = r or 0
            h_web = h - 2*tf
            A_radius = (np.pi * r**2) / 4
            I_flens = 2 * (b * tf**3 / 12 + b * tf * (h/2 - tf/2)**2)
            I_web = t * h_web**3 / 12
            I_radius = 4 * (A_radius * ((h-2*tf-r)/2)**2 + np.pi * r**4 / 64)
            return I_flens + I_web + I_radius

    def calculate_results(self, x, loads, L, E, I):
        """Bereken moment, dwarskracht en doorbuiging volgens elasticiteitstheorie"""
        moment = np.zeros_like(x)
        shear = np.zeros_like(x)
        deflection = np.zeros_like(x)
        
        for load in loads:
            if load["type"] == "Puntlast":
                F = load["value"]
                a = load["position"]
                
                # Moment volgens superposititie
                moment += np.where(x <= a,
                                F * x * (L-a) / L,
                                F * a * (L-x) / L)
                
                # Dwarskracht met sprongfunctie
                shear += np.where(x < a,
                               F * (L-a) / L,
                               -F * a / L)
                
                # Doorbuiging volgens elastische lijn
                deflection += np.where(x <= a,
                                    F * x * (L**2 - x**2 - a**2) / (6*E*I*L),
                                    F * a * (L**2 - a**2 - x**2) / (6*E*I*L))
            
            elif load["type"] == "Gelijkmatig":
                q = load["value"]
                
                # Moment volgens integratie
                moment += q * x * (L-x) / 2
                
                # Dwarskracht als afgeleide van moment
                shear += q * (L/2 - x)
                
                # Doorbuiging volgens dubbele integratie
                deflection += q * x * (L**3 - 2*L*x**2 + x**3) / (24*E*I*L)
            
            elif load["type"] == "Moment":
                M = load["value"]
                a = load["position"]
                
                # Moment met sprongfunctie
                moment += np.where(x < a, 0, M)
                
                # Doorbuiging door moment
                deflection += np.where(x <= a,
                                    M * x**2 * (3*L - x) / (6*E*I*L),
                                    M * (3*L*x**2 - x**3) / (6*E*I*L))
        
        return moment, shear, deflection

    def calculate_section_properties(self, h, b, t, tf=None, r=None, profile_type="Koker"):
        """Bereken doorsnede-eigenschappen"""
        if profile_type == "Koker":
            A = b*h - (b-2*t)*(h-2*t)
            I = self.calculate_I(h, b, t, None, r, profile_type)
            W = 2*I/h
            i = np.sqrt(I/A)
            return {
                "A": A,  # Oppervlakte [mm²]
                "I": I,  # Traagheidsmoment [mm⁴]
                "W": W,  # Weerstandsmoment [mm³]
                "i": i   # Traagheidsstraal [mm]
            }
        else:
            A = 2*b*tf + (h-2*tf)*t
            I = self.calculate_I(h, b, t, tf, r, profile_type)
            W = 2*I/h
            i = np.sqrt(I/A)
            return {
                "A": A,
                "I": I,
                "W": W,
                "i": i
            }

# Instantieer calculator
calculator = BuigingsCalculator()

@app.route('/')
def home():
    return render_template('index.html', 
                         materials=calculator.materials,
                         profiles=calculator.standard_profiles)

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.json
    
    # Haal parameters uit request
    material = data['material']
    profile_type = data['profile_type']
    h = float(data['height'])
    b = float(data['width'])
    t = float(data['thickness'])
    tf = float(data.get('flange_thickness', 0))
    r = float(data.get('radius', 0))
    L = float(data['length'])
    loads = data['loads']
    
    # Bereken doorsnede-eigenschappen
    props = calculator.calculate_section_properties(h, b, t, tf, r, profile_type)
    
    # Bereken resultaten
    x = np.linspace(0, L, 100)
    I = props["I"]
    E = calculator.materials[material]["E"]
    moment, shear, deflection = calculator.calculate_results(x, loads, L, E, I)
    
    # Bereken spanningen
    y_max = h/2
    sigma_b = np.abs(moment) * y_max / I  # Buigspanning
    tau_v = 1.5 * np.abs(shear) / props["A"]  # Schuifspanning (vereenvoudigd)
    sigma_v = np.sqrt(sigma_b**2 + 3*tau_v**2)  # Von Mises spanning
    
    # Unity checks volgens Eurocode 3
    sigma_y = calculator.materials[material]["sigma_y"]
    gamma_M0 = calculator.materials[material]["gamma_M0"]
    unity_check_normal = np.max(np.abs(sigma_b)) / (sigma_y / gamma_M0)
    unity_check_shear = np.max(np.abs(tau_v)) / ((sigma_y / np.sqrt(3)) / gamma_M0)
    unity_check_combined = np.max(np.abs(sigma_v)) / (sigma_y / gamma_M0)
    
    # Maak plots
    fig = plt.figure(figsize=(12, 8))
    fig.suptitle(f"Berekeningsresultaten - {profile_type}", fontsize=14)
    
    # Subplot grid
    gs = fig.add_gridspec(3, 2, hspace=0.4)
    
    # Moment diagram
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.plot(x, moment/1000, 'b-', linewidth=2)
    ax1.set_title("Momentenlijn")
    ax1.set_xlabel("Positie [mm]")
    ax1.set_ylabel("Moment [kNm]")
    ax1.grid(True, alpha=0.3)
    
    # Dwarskracht diagram
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.plot(x, shear/1000, 'g-', linewidth=2)
    ax2.set_title("Dwarskrachtenlijn")
    ax2.set_xlabel("Positie [mm]")
    ax2.set_ylabel("Dwarskracht [kN]")
    ax2.grid(True, alpha=0.3)
    
    # Doorbuiging
    ax3 = fig.add_subplot(gs[1, :])
    ax3.plot(x, deflection, 'r-', linewidth=2)
    ax3.set_title(f"Doorbuigingslijn (max: {np.max(np.abs(deflection)):.2f} mm)")
    ax3.set_xlabel("Positie [mm]")
    ax3.set_ylabel("Doorbuiging [mm]")
    ax3.grid(True, alpha=0.3)
    
    # Spanningen
    ax4 = fig.add_subplot(gs[2, :])
    ax4.plot(x, sigma_b, 'b-', label='Buigspanning', linewidth=2)
    ax4.plot(x, tau_v, 'g-', label='Schuifspanning', linewidth=2)
    ax4.plot(x, sigma_v, 'r-', label='Von Mises spanning', linewidth=2)
    ax4.axhline(y=sigma_y/gamma_M0, color='k', linestyle='--', label='Toelaatbare spanning')
    ax4.set_title("Spanningsverdeling")
    ax4.set_xlabel("Positie [mm]")
    ax4.set_ylabel("Spanning [N/mm²]")
    ax4.grid(True, alpha=0.3)
    ax4.legend()
    
    plt.tight_layout()
    
    # Convert plot to base64 string
    buf = io.BytesIO()
    FigureCanvas(fig).print_png(buf)
    plot_url = base64.b64encode(buf.getvalue()).decode('utf8')
    plt.close()
    
    return jsonify({
        'plot': plot_url,
        'section_properties': {
            'A': props["A"],
            'I': props["I"],
            'W': props["W"],
            'i': props["i"]
        },
        'max_values': {
            'moment': float(np.max(np.abs(moment))),
            'shear': float(np.max(np.abs(shear))),
            'deflection': float(np.max(np.abs(deflection))),
            'sigma_b': float(np.max(np.abs(sigma_b))),
            'tau_v': float(np.max(np.abs(tau_v))),
            'sigma_v': float(np.max(np.abs(sigma_v)))
        },
        'unity_checks': {
            'normal': float(unity_check_normal),
            'shear': float(unity_check_shear),
            'combined': float(unity_check_combined)
        }
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
