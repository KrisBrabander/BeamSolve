import sys
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QLabel, QLineEdit, QPushButton, QGridLayout)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class BuigingsCalculator(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Buigingsberekeningen')
        self.setGeometry(100, 100, 1200, 800)
        
        # Maak centrale widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QHBoxLayout(central_widget)
        
        # Invoerpaneel links
        input_widget = QWidget()
        input_layout = QVBoxLayout(input_widget)
        input_layout.addWidget(QLabel('<h2>Invoergegevens</h2>'))
        
        # Profielgegevens
        input_layout.addWidget(QLabel('<b>1. Profielgegevens</b>'))
        form_layout = QGridLayout()
        
        # Labels en invoervelden
        labels = ['Hoogte (mm):', 'Breedte (mm):', 'Wanddikte (mm):']
        self.inputs = {}
        
        for i, label in enumerate(labels):
            form_layout.addWidget(QLabel(label), i, 0)
            line_edit = QLineEdit()
            line_edit.setPlaceholderText('0.0')
            self.inputs[label] = line_edit
            form_layout.addWidget(line_edit, i, 1)
        
        input_layout.addLayout(form_layout)
        
        # Overspanning
        input_layout.addWidget(QLabel('<b>2. Overspanning</b>'))
        form_layout2 = QGridLayout()
        form_layout2.addWidget(QLabel('Lengte (mm):'), 0, 0)
        self.lengte_input = QLineEdit()
        self.lengte_input.setPlaceholderText('1000.0')
        form_layout2.addWidget(self.lengte_input, 0, 1)
        input_layout.addLayout(form_layout2)
        
        # Belasting
        input_layout.addWidget(QLabel('<b>3. Belasting</b>'))
        form_layout3 = QGridLayout()
        form_layout3.addWidget(QLabel('Kracht (N):'), 0, 0)
        self.kracht_input = QLineEdit()
        self.kracht_input.setPlaceholderText('1000.0')
        form_layout3.addWidget(self.kracht_input, 0, 1)
        
        form_layout3.addWidget(QLabel('Positie (mm):'), 1, 0)
        self.positie_input = QLineEdit()
        self.positie_input.setPlaceholderText('500.0')
        form_layout3.addWidget(self.positie_input, 1, 1)
        
        input_layout.addLayout(form_layout3)
        
        # Bereken knop
        self.bereken_button = QPushButton('Bereken')
        self.bereken_button.clicked.connect(self.update_plots)
        input_layout.addWidget(self.bereken_button)
        
        input_layout.addStretch()
        layout.addWidget(input_widget)
        
        # Grafieken rechts
        plot_widget = QWidget()
        plot_layout = QGridLayout(plot_widget)
        
        # Maak 4 plots
        self.figure = Figure(figsize=(12, 8))
        self.canvas = FigureCanvas(self.figure)
        plot_layout.addWidget(self.canvas, 0, 0)
        
        self.axes = []
        titles = ['Momentenlijn', 'Dwarskrachtenlijn', 'Doorbuiging', 'Spanningsverdeling']
        ylabels = ['Moment (Nmm)', 'Dwarskracht (N)', 'Doorbuiging (mm)', 'Spanning (N/mm²)']
        
        for i in range(4):
            ax = self.figure.add_subplot(2, 2, i+1)
            ax.set_title(titles[i])
            ax.set_xlabel('Positie (mm)')
            ax.set_ylabel(ylabels[i])
            ax.grid(True)
            self.axes.append(ax)
        
        self.figure.tight_layout()
        layout.addWidget(plot_widget)
        
        # Standaardwaarden
        self.inputs['Hoogte (mm):'].setText('100')
        self.inputs['Breedte (mm):'].setText('50')
        self.inputs['Wanddikte (mm):'].setText('5')
        self.lengte_input.setText('1000')
        self.kracht_input.setText('1000')
        self.positie_input.setText('500')
        
        # Eerste berekening
        self.update_plots()
    
    def bereken_traagheidsmoment(self, h, b, t):
        """Berekent traagheidsmoment voor koker"""
        h_binnen = h - 2 * t
        b_binnen = b - 2 * t
        return (b * h**3 - b_binnen * h_binnen**3) / 12
    
    def bereken_weerstandsmoment(self, I, h):
        """Berekent weerstandsmoment"""
        return I / (h / 2)
    
    def bereken_moment(self, F, a, L, x):
        """Berekent moment op positie x"""
        if x <= a:
            return F * a * x / L
        else:
            return F * (L - x) * (L - a) / L
    
    def bereken_dwarskracht(self, F, a, L, x):
        """Berekent dwarskracht op positie x"""
        if x < a:
            return F * (L - a) / L
        else:
            return -F * a / L
    
    def bereken_doorbuiging(self, F, a, L, x, EI):
        """Berekent doorbuiging op positie x"""
        return F * x * (L - x) * (L + x - a) / (6 * L * EI)
    
    def update_plots(self):
        try:
            # Lees invoerwaarden
            h = float(self.inputs['Hoogte (mm):'].text())
            b = float(self.inputs['Breedte (mm):'].text())
            t = float(self.inputs['Wanddikte (mm):'].text())
            L = float(self.lengte_input.text())
            F = float(self.kracht_input.text())
            a = float(self.positie_input.text())
            
            # Bereken eigenschappen
            I = self.bereken_traagheidsmoment(h, b, t)
            W = self.bereken_weerstandsmoment(I, h)
            E = 210000  # N/mm2
            EI = E * I
            
            # Bereken waarden
            x = np.linspace(0, L, 100)
            moment = [self.bereken_moment(F, a, L, xi) for xi in x]
            dwarskracht = [self.bereken_dwarskracht(F, a, L, xi) for xi in x]
            doorbuiging = [self.bereken_doorbuiging(F, a, L, xi, EI) for xi in x]
            spanning = [abs(M) / W for M in moment]
            
            # Update plots
            for ax in self.axes:
                ax.clear()
                ax.grid(True)
            
            self.axes[0].plot(x, moment)
            self.axes[0].set_title('Momentenlijn')
            self.axes[0].set_xlabel('Positie (mm)')
            self.axes[0].set_ylabel('Moment (Nmm)')
            
            self.axes[1].plot(x, dwarskracht)
            self.axes[1].set_title('Dwarskrachtenlijn')
            self.axes[1].set_xlabel('Positie (mm)')
            self.axes[1].set_ylabel('Dwarskracht (N)')
            
            self.axes[2].plot(x, doorbuiging)
            self.axes[2].set_title('Doorbuiging')
            self.axes[2].set_xlabel('Positie (mm)')
            self.axes[2].set_ylabel('Doorbuiging (mm)')
            
            self.axes[3].plot(x, spanning)
            self.axes[3].set_title('Spanningsverdeling')
            self.axes[3].set_xlabel('Positie (mm)')
            self.axes[3].set_ylabel('Spanning (N/mm²)')
            
            self.figure.tight_layout()
            self.canvas.draw()
            
        except ValueError:
            print("Voer geldige numerieke waarden in")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = BuigingsCalculator()
    window.show()
    sys.exit(app.exec_())
