from tkinter import ttk
import tkinter as tk

def apply_modern_style():
    # Kleurenpalet
    colors = {
        'bg_dark': '#2E3440',        # Donkere achtergrond
        'bg_light': '#3B4252',       # Lichtere achtergrond
        'accent': '#88C0D0',         # Accent kleur (lichtblauw)
        'text': '#ECEFF4',           # Tekst kleur (wit)
        'text_dark': '#D8DEE9',      # Donkerdere tekst
        'highlight': '#5E81AC',      # Highlight kleur
        'warning': '#BF616A',        # Waarschuwing kleur
        'success': '#A3BE8C'         # Success kleur
    }

    style = ttk.Style()
    style.theme_use('clam')

    # Algemene stijl
    style.configure('.',
        background=colors['bg_dark'],
        foreground=colors['text'],
        fieldbackground=colors['bg_light'],
        troughcolor=colors['bg_light'],
        selectbackground=colors['accent'],
        selectforeground=colors['bg_dark']
    )

    # Frame stijl
    style.configure('TFrame',
        background=colors['bg_dark']
    )

    # Label stijl
    style.configure('TLabel',
        background=colors['bg_dark'],
        foreground=colors['text']
    )

    # Entry stijl
    style.configure('TEntry',
        fieldbackground=colors['bg_light'],
        foreground=colors['text'],
        selectbackground=colors['accent'],
        selectforeground=colors['bg_dark']
    )
    style.map('TEntry',
        fieldbackground=[('focus', colors['bg_light'])],
        selectbackground=[('focus', colors['accent'])]
    )

    # Button stijl
    style.configure('TButton',
        background=colors['accent'],
        foreground=colors['bg_dark'],
        padding=5
    )
    style.map('TButton',
        background=[('active', colors['highlight'])],
        foreground=[('active', colors['text'])]
    )

    # LabelFrame stijl
    style.configure('TLabelframe',
        background=colors['bg_dark'],
        foreground=colors['text']
    )
    style.configure('TLabelframe.Label',
        background=colors['bg_dark'],
        foreground=colors['accent']
    )

    return colors
