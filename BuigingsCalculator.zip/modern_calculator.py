import sys
import numpy as np
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                           QHBoxLayout, QLabel, QLineEdit, QPushButton, QFrame,
                           QGraphicsDropShadowEffect, QListWidget, QDialog)
from PyQt6.QtCore import Qt, QPoint
from PyQt6.QtGui import QPainter, QColor, QPen, QBrush
import matplotlib
matplotlib.use('QtAgg')  # Set backend before importing pyplot
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class ModernLineEdit(QLineEdit):
    def __init__(self, placeholder="", parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QLineEdit {
                border: 2px solid #2c3e50;
                border-radius: 10px;
                padding: 8px;
                background-color: #34495e;
                color: #ecf0f1;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 2px solid #3498db;
                background-color: #2c3e50;
            }
        """)
        self.setPlaceholderText(placeholder)
        
        # Voeg schaduw toe
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor("#1a1a1a"))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)

class ModernButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                border: none;
                border-radius: 10px;
                padding: 10px 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QPushButton:pressed {
                background-color: #2574a9;
            }
        """)
        
        # Voeg schaduw toe
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor("#1a1a1a"))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)

class ModernFrame(QFrame):
    def __init__(self, title="", parent=None):
        super().__init__(parent)
        self.title = title
        self.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                border-radius: 15px;
                padding: 20px;
            }
        """)
        
        # Voeg schaduw toe
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor("#1a1a1a"))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)
        
        # Layout
        self.layout = QVBoxLayout(self)
        if title:
            title_label = QLabel(title)
            title_label.setStyleSheet("""
                QLabel {
                    color: #3498db;
                    font-size: 16px;
                    font-weight: bold;
                    padding-bottom: 10px;
                }
            """)
            self.layout.addWidget(title_label)

class BalkVisualisatie(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(200)
        self.belastingen = []
        self.setStyleSheet("background-color: #2c3e50; border-radius: 15px;")
        
        # Voeg schaduw toe
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor("#1a1a1a"))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)
    
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Teken achtergrond
        painter.fillRect(self.rect(), QColor("#2c3e50"))
        
        # Afmetingen
        margin = 50
        balk_hoogte = 40
        width = self.width()
        height = self.height()
        y_midden = height / 2
        
        # Teken balk met gradient
        gradient = QColor("#3498db")
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(gradient))
        painter.drawRoundedRect(margin, y_midden - balk_hoogte/2,
                              width - 2*margin, balk_hoogte, 5, 5)
        
        # Teken steunpunten
        painter.setPen(QPen(QColor("#e74c3c"), 2))
        painter.setBrush(QBrush(QColor("#e74c3c")))
        
        # Links steunpunt
        points = [
            QPoint(margin, y_midden + balk_hoogte/2),
            QPoint(margin - 15, y_midden + balk_hoogte/2 + 30),
            QPoint(margin + 15, y_midden + balk_hoogte/2 + 30)
        ]
        painter.drawPolygon(*points)
        
        # Rechts steunpunt
        points = [
            QPoint(width - margin, y_midden + balk_hoogte/2),
            QPoint(width - margin - 15, y_midden + balk_hoogte/2 + 30),
            QPoint(width - margin + 15, y_midden + balk_hoogte/2 + 30)
        ]
        painter.drawPolygon(*points)
        
        # Teken belastingen
        painter.setPen(QPen(QColor("#2ecc71"), 2))
        for pos, kracht in self.belastingen:
            x = margin + pos * (width - 2*margin) / 1000  # Schaal naar pixels
            # Pijl
            painter.drawLine(x, y_midden - balk_hoogte/2 - 40,
                           x, y_midden - balk_hoogte/2)
            # Pijlpunt
            points = [
                QPoint(x, y_midden - balk_hoogte/2),
                QPoint(x - 5, y_midden - balk_hoogte/2 - 10),
                QPoint(x + 5, y_midden - balk_hoogte/2 - 10)
            ]
            painter.setBrush(QBrush(QColor("#2ecc71")))
            painter.drawPolygon(*points)
            # Tekst
            painter.drawText(x - 20, y_midden - balk_hoogte/2 - 50,
                           f"{kracht}N")

class ModernBuigingsCalculator(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Moderne Buigingsberekeningen")
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
        """)
        self.setMinimumSize(1200, 800)
        
        # Hoofdwidget
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout(main_widget)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Balk visualisatie
        self.balk_vis = BalkVisualisatie()
        layout.addWidget(self.balk_vis)
        
        # Invoer sectie
        input_section = QHBoxLayout()
        
        # Profielgegevens
        profiel_frame = ModernFrame("Profielgegevens")
        profiel_layout = QVBoxLayout()
        
        # Invoervelden
        self.inputs = {}
        for label, default in [
            ("Hoogte (mm)", "100"),
            ("Breedte (mm)", "50"),
            ("Wanddikte (mm)", "5"),
            ("Lengte (mm)", "1000")
        ]:
            field_layout = QHBoxLayout()
            field_label = QLabel(label)
            field_label.setStyleSheet("color: #ecf0f1; font-size: 14px;")
            field_layout.addWidget(field_label)
            
            input_field = ModernLineEdit(default)
            self.inputs[label] = input_field
            field_layout.addWidget(input_field)
            
            profiel_layout.addLayout(field_layout)
        
        profiel_frame.layout.addLayout(profiel_layout)
        input_section.addWidget(profiel_frame)
        
        # Belastingen
        belasting_frame = ModernFrame("Belastingen")
        belasting_layout = QVBoxLayout()
        
        self.belasting_list = QListWidget()
        self.belasting_list.setStyleSheet("""
            QListWidget {
                background-color: #34495e;
                border-radius: 10px;
                padding: 10px;
                color: #ecf0f1;
                font-size: 14px;
            }
            QListWidget::item {
                padding: 5px;
                border-bottom: 1px solid #2c3e50;
            }
            QListWidget::item:selected {
                background-color: #3498db;
                border-radius: 5px;
            }
        """)
        belasting_layout.addWidget(self.belasting_list)
        
        # Knoppen
        buttons_layout = QHBoxLayout()
        verwijder_btn = ModernButton("Verwijder")
        verwijder_btn.clicked.connect(self.verwijder_belasting)
        bereken_btn = ModernButton("Bereken")
        bereken_btn.clicked.connect(self.update_grafieken)
        
        buttons_layout.addWidget(verwijder_btn)
        buttons_layout.addWidget(bereken_btn)
        belasting_layout.addLayout(buttons_layout)
        
        belasting_frame.layout.addLayout(belasting_layout)
        input_section.addWidget(belasting_frame)
        
        layout.addLayout(input_section)
        
        # Grafieken
        plot_frame = ModernFrame("Resultaten")
        self.fig = Figure(figsize=(12, 4), facecolor="#2c3e50")
        self.canvas = FigureCanvas(self.fig)
        
        # Stel plot stijl in
        plt.style.use('dark_background')
        self.axes = []
        titles = ['Momentenlijn', 'Dwarskrachtenlijn', 'Doorbuiging', 'Spanningsverdeling']
        for i, title in enumerate(titles, 1):
            ax = self.fig.add_subplot(141 + i - 1)
            ax.set_facecolor("#34495e")
            ax.set_title(title, color="#ecf0f1")
            ax.grid(True, color="#7f8c8d")
            self.axes.append(ax)
        
        self.fig.tight_layout()
        plot_frame.layout.addWidget(self.canvas)
        layout.addWidget(plot_frame)
        
        # Initialisatie
        self.balk_vis.setMouseTracking(True)
        self.balk_vis.mousePressEvent = self.on_balk_click
        self.update_grafieken()
    
    def on_balk_click(self, event):
        # Converteer klik naar balkpositie
        margin = 50
        width = self.balk_vis.width()
        x = event.position().x()
        pos = (x - margin) / (width - 2*margin) * 1000
        
        if 0 <= pos <= 1000:
            # Maak een modern dialoogvenster
            dialog = QDialog(self)
            dialog.setWindowTitle("Voer kracht in")
            dialog.setStyleSheet("""
                QDialog {
                    background-color: #2c3e50;
                    border-radius: 15px;
                }
            """)
            dialog.setFixedSize(300, 150)
            
            layout = QVBoxLayout(dialog)
            
            # Kracht invoer
            kracht_input = ModernLineEdit("1000")
            kracht_input.setPlaceholderText("Voer kracht in (N)")
            layout.addWidget(kracht_input)
            
            # Knoppen
            btn_layout = QHBoxLayout()
            ok_btn = ModernButton("OK")
            cancel_btn = ModernButton("Annuleren")
            
            ok_btn.clicked.connect(lambda: self.voeg_belasting_toe(pos, float(kracht_input.text())))
            cancel_btn.clicked.connect(dialog.reject)
            
            btn_layout.addWidget(cancel_btn)
            btn_layout.addWidget(ok_btn)
            layout.addLayout(btn_layout)
            
            dialog.exec()
    
    def voeg_belasting_toe(self, pos, kracht):
        self.balk_vis.belastingen.append((pos, kracht))
        self.belasting_list.addItem(f"Pos: {pos:.0f} mm, Kracht: {kracht:.0f} N")
        self.balk_vis.update()
        self.update_grafieken()
    
    def verwijder_belasting(self):
        current = self.belasting_list.currentRow()
        if current >= 0:
            del self.balk_vis.belastingen[current]
            self.belasting_list.takeItem(current)
            self.balk_vis.update()
            self.update_grafieken()
    
    def update_grafieken(self):
        try:
            # Bereken waarden
            L = float(self.inputs["Lengte (mm)"].text())
            x = np.linspace(0, L, 100)
            
            if self.balk_vis.belastingen:
                moment = np.zeros_like(x)
                dwarskracht = np.zeros_like(x)
                doorbuiging = np.zeros_like(x)
                
                for pos, F in self.balk_vis.belastingen:
                    # Moment
                    moment += np.where(x <= pos,
                                     F * pos * x / L,
                                     F * (L - x) * (L - pos) / L)
                    
                    # Dwarskracht
                    dwarskracht += np.where(x < pos,
                                          F * (L - pos) / L,
                                          -F * pos / L)
                    
                    # Doorbuiging
                    E = 210000  # N/mm2
                    I = (float(self.inputs["Breedte (mm)"].text()) *
                         float(self.inputs["Hoogte (mm)"].text())**3) / 12
                    EI = E * I
                    doorbuiging += F * x * (L - x) * (L + x - pos) / (6 * L * EI)
                
                # Spanning
                h = float(self.inputs["Hoogte (mm)"].text())
                spanning = np.abs(moment) * (h/2) / I
                
                # Update plots
                for ax in self.axes:
                    ax.clear()
                    ax.grid(True, color="#7f8c8d")
                
                self.axes[0].plot(x, moment, color="#3498db")
                self.axes[0].set_title("Momentenlijn", color="#ecf0f1")
                
                self.axes[1].plot(x, dwarskracht, color="#2ecc71")
                self.axes[1].set_title("Dwarskrachtenlijn", color="#ecf0f1")
                
                self.axes[2].plot(x, doorbuiging, color="#e74c3c")
                self.axes[2].set_title("Doorbuiging", color="#ecf0f1")
                
                self.axes[3].plot(x, spanning, color="#f1c40f")
                self.axes[3].set_title("Spanningsverdeling", color="#ecf0f1")
                
                self.fig.tight_layout()
                self.canvas.draw()
        
        except ValueError:
            pass

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = ModernBuigingsCalculator()
    window.show()
    sys.exit(app.exec())
