import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QLabel

def main():
    app = QApplication(sys.argv)
    window = QMainWindow()
    window.setWindowTitle("Test Window")
    window.setGeometry(100, 100, 400, 300)
    
    label = QLabel("Test Label", window)
    label.setGeometry(50, 50, 200, 50)
    
    window.show()
    return app.exec()

if __name__ == "__main__":
    sys.exit(main())
